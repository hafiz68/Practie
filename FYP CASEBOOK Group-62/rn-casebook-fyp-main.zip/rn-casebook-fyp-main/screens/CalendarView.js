import React from "react";
import { View, Text } from "react-native";

import { styles } from "../shared/styles/styles";

const CalendarView = ({ navigation }) => {
  return (
    <View style={styles.screenContainer}>
      <Text>Calendar View Screen</Text>
    </View>
  );
};

export default CalendarView;
