export const SUPABASE_URL = "https://cknhwrfmbqhqxranbixi.supabase.co";
export const SUPABASE_ANON_KEY =
	"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlhdCI6MTYzMjMzMzE5NiwiZXhwIjoxOTQ3OTA5MTk2fQ.O3WvPRRbxmaEeOiewR7sIArC_NVXlYn_8fEbEd_rfpU";
